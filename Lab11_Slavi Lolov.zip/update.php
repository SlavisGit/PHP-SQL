<?php
    include "config.php";
    $result =mysqli_query($dbConn, "SELECT * FROM deliveryman WHERE company='Лазур'");
    echo "<table border='1'>";
    echo "<th> Deliveryman </th>";
    echo "<th> Bulstat </th>";
    echo "<th> Contact </th>";
    while($row = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>".$row['company']."</td>"."<td>".$row['bulstat']."</td>"."<td>".$row['contact']."</td>";
            
    }
    echo "</tr>";
    echo "<td colspan = '5', align = 'center'>"."<a href= update1.php>Update</a>"."</td>";
    echo "</table>";
?>
