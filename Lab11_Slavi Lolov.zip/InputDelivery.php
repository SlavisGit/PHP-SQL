<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       <form name="1" method="post">
            Input firm: <input type="text" name="firm"/> <br>
            Input Bulstat: <input type="text" name="bulstat"> <br><!-- comment -->
         <?php
            include "config.php";
            $result = mysqli_query($dbConn, "SELECT * FROM city");
            echo "Сhoose address: <select size='1'  name='id_city'>";
            echo " <option disabled>City</option>";
            while($index = mysqli_fetch_array($result)){
            echo "<option value=".$index['id_city'].">".$index['city']."</option>";
            }
            echo "</select></p>";
        ?>
            Input Phone number: <input type="text" name="pnumber"> <br>
            Input Year of registration: <input type="text" name="register"> <br>
            Input Contacts: <input type="text" name="contacts"> <br>
            <input type="submit" name="submit" value="Submit"/>
        </form>
        <?php
        include "config.php";
        if(isset($_POST['submit'])) {
           $firm = $_POST['firm'];
           $bulstat = $_POST['bulstat'];
           $address = $_POST['id_city'];
           $pnumber = $_POST['pnumber'];
           $register = $_POST['register'];
           $contact = $_POST['contacts'];
           if (!empty($firm) && !empty($bulstat) && !empty($address) && !empty($pnumber) && !empty($register) && !empty($contact )) {
                
                $sql="INSERT INTO deliveryman (company, bulstat, id_city, mobile_number, register_year,contact ) VALUES ('$firm', '$bulstat', '$address', '$pnumber', '$register', '$contact')";
                $result = mysqli_query($dbConn,$sql);
                if (!$result) {
                    die('Грешка!!!');
                }
                echo "Добавихте един запис.";
            } else{
                echo "Не сте въвели всички данни!!!";
            }
            $result =mysqli_query($dbConn, "SELECT * FROM deliveryman");
            echo "<table border='1'>";
            echo "<th> Deliveryman </th>";
            echo "<th> Bulstat </th>";
            echo "<th> Address </th>";
            echo "<th> Phone number </th>";
            echo "<th> Year of registration </th>";
            echo "<th> Contacts </th>";
            while($row = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$row['company']."</td>"."<td>".$row['bulstat']."</td>"."<td>".$row['id_city']."</td>"."<td>".
                        $row['mobile_number']."</td>"."<td>".$row['register_year']."</td>"."<td>".$row['contact']."</td>";
            
            }
            echo "</tr>";
            echo "</table>";
        }
        ?>
    </body>
</html>
