<?php
 include "config.php";
 $result =mysqli_query($dbConn, "SELECT * FROM deliveryman WHERE company='Орхидея'");
 echo "<table border='1'>";
 echo "<th> Deliveryman </th>";
 echo "<th> Bulstat </th>";
 while($row = mysqli_fetch_array($result)){
    echo "<tr>";
    echo "<td>".$row['company']."</td>"."<td>".$row['bulstat']."</td>";
            
}
 echo "</tr>";
 echo "<td colspan = '5', align = 'center'>"."<a href= delete1.php>Delete</a>"."</td>";
 echo "</table>";
?>
