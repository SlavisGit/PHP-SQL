<?php
include "config.php";
    $sql = "DELETE FROM deliveryman WHERE company='Орхидея'";
    $result = mysqli_query($dbConn,$sql);
    $result = mysqli_query($dbConn,"SELECT * FROM deliveryman");
    echo "<ol>";
    while($row = mysqli_fetch_array($result)){
         echo "<li>".$row['company']."</li>";
    }
    echo "</ol>";
//DELETE FROM Customers WHERE CustomerName='Alfreds Futterkiste';
?>
