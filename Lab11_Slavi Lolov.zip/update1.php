<?php

    include "config.php";
    $sql = "UPDATE deliveryman SET contact='Мария Руменова' WHERE company='Лазур'";
    mysqli_query($dbConn,$sql);
    $result = mysqli_query($dbConn,"SELECT * FROM deliveryman");
    echo "<ol>";
    while($row = mysqli_fetch_array($result)){
         echo "<li>".$row['company'].", ".$row['contact']."</li>";
    }
    echo "</ol>";
?>