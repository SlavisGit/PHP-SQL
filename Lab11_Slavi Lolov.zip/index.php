<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
          echo "<h1>"."Deliverymans"."</h1>"."<br>";
          echo "<a href= input_city.php>Enter city</a>"."<br>";
          echo "<a href= inputDelivery.php>Enter deliveryman</a>"."<br>";
          echo "<a href= update.php>Update</a>"."<br>";
          echo "<a href= delete.php>Delete</a>";
        ?>
    </body>
</html>
