<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body> 
        <form name="1" method="post">
            Input city: <input type="text" name="city"/> <br>
        <input type="submit" name="submit" value="Submit"/>
        </form>
        <?php
        include "config.php";
        if(isset($_POST['submit'])) {
           $city = $_POST['city'];
           if (!empty($city)) {
                $sql="INSERT INTO city (city) VALUES ('$city')";
                $result = mysqli_query($dbConn,$sql);
                if (!$result) {
                    die('Грешка!!!');
                }
                echo "Добавихте един запис.";
            } else{
                echo "Не сте въвели всички данни!!!";
            }
           $result =mysqli_query($dbConn, "SELECT * FROM city ");
            echo "<table border='1'>";
            echo "<th> Number </th>";
            echo "<th> City </th>";
           
            while($row = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".$row['id_city']."</td>"."<td>".$row['city']."</td>";
            
            }
            echo "</tr>";
            echo "</table>";
        }
        ?>
    </body>
</html>